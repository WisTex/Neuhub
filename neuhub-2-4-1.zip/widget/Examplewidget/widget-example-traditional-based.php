<?php 

function widget_slugfish2($args) { 

/*
... widget code goes here.
... The function returns a string which is the HTML content of the widget. 
... $args is a named array which is passed any [var] variables from the layout editor 
... For instance [widget=slugfish][var=count]3[/var][/widget] will populate $args with 
... [ 'count' => 3 ] 
*/

}