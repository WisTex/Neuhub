<?php

require_once('view/theme/redbasic/php/config.php');
require_once('view/theme/redbasic/php/style.php');

echo @file_get_contents('view/theme/redbasic-child/css/style.css');
