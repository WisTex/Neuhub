<?php

/**
 *   * Name: Neuhub Red Dash
 *   * Description: A proof of concept theme combining Redbasic with SB Admin as the base.
 *   * Version: 0.3
 *   * MinVersion: 6.5.13
 *   * MaxVersion: 10.0
 *   * Author: Scott M. Stolz
 *   * Maintainer: Scott M. Stolz
 *   * Respository: https://github.com/WisTex/Neuhub
 *   * Compat: Hubzilla [*]
 *
 */

function neuhubreddash_init(&$App) {

    App::$theme_info['extends'] = 'redbasic';


}
